import numpy as np
import linecache
import tensorflow as tf


class SC_DataGenerator(object):
    np.random.seed(1)
    def gen_instance(self,dimension, f):
        num_service = []
        f.readline()
        line = f.readline()
        candidates_c = line.split(' ')
        candidates = []
        for index in range(len(candidates_c)):
            candidates.append(candidates_c[index])
        for candidate in candidates:
            num = 0
            f1 = open('服务名聚类最终结果/'+candidate+'.txt')
            line1 = f1.readline()
            while line1:
                num = num+1
                line1 = f1.readline()
            num_service.append(num)

        return num_service


    def train_batch(self, dimension, position, i, config=None, calattr=None):  #dimension:服务质量类别数
        f = open(position + '/' + i + '/nodeSet.txt','r', encoding='utf-8')

        num = self.gen_instance(dimension, f)
        count = 0
        for i in num:
            count = count+i

        if config is not None and config.use_graph_features and calattr is not None:
            graph_features = calattr.extract_graph_features()
            input_ = self._format_graph_features(graph_features)
            print(f"[Graph-Aware Mode] Input shape: {input_.shape}")
        else:
            raise ValueError("config and calattr are empty")

        return input_, num, count

    def _format_graph_features(self, features):

        # Normalize each feature column separately (per-feature)
        normalized = np.zeros_like(features, dtype=float)
        for col in range(features.shape[1]):  # 8 columns
            col_min = np.min(features[:, col])
            col_max = np.max(features[:, col])
            if col_max - col_min > 0:
                normalized[:, col] = (features[:, col] - col_min) / (col_max - col_min)
            else:
                normalized[:, col] = features[:, col]

        # Flatten from (node_num, 8) to (node_num * 8)
        flat_features = normalized.flatten()

        # Reshape to (1, node_num * 8) for batch processing
        input_ = flat_features.reshape(1, -1)

        return input_

    def _normalize_features(self, features):

        min_val = np.min(features)
        max_val = np.max(features)

        if max_val - min_val > 0:
            normalized = (features - min_val) / (max_val - min_val)
        else:

            normalized = features

        return normalized

if __name__ == "__main__":
    from calattr import Calattr

    sc = SC_DataGenerator()
    input_baseline,num,count = sc.train_batch(5, 'test', '10/2')
    print('input: ',input_baseline.shape)
    print('num: ',num)
    print('count: ',count)

    # Test graph-aware mode
    print('\nGraph-aware mode:')
    from config import get_config

    config, _ = get_config()
    config.use_graph_features = True
    config.node_num = 10

    calattr = Calattr()
    calattr.init(10, 'test', '10/2')

    input_graph, num, count = sc.train_batch(5, 'test', '10/2', config, calattr)
    print('  Input shape:', input_graph.shape)
    print('  Num services:', num)
    print('  Total count:', count)








