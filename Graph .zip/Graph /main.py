# -*- coding: utf-8 -*-

import tensorflow as tf
from actor import Actor
from optimizer import Optimize
from config import get_config
import numpy as np
from sc_dataset import SC_DataGenerator
from calattr import Calattr
from pretrain import Pretrain
import csv
import random
import time
import os
import generate



def main(config,calattr,inputs,num,evaluations_number):
    tf.reset_default_graph()
    start = time.time()

    graph_feature_dim = config.node_num * 8
    input = tf.placeholder(tf.float32, [1, graph_feature_dim], name="input_raw")

    num_service = tf.placeholder(tf.int32, [config.node_num], name="num_service")
    reward = tf.placeholder(tf.float32, [config.sample_num], name="reward")
    label = tf.placeholder(tf.int32,[config.node_num], name="label")

    actor = Actor(config)
    pre = Pretrain(config)
    optimize = Optimize(config)

    pos, logsoftmax, scores = actor(input, num_service)
    optimize.build_optim(reward, logsoftmax)
    pre.build_optim(scores,label,num_service)

    min = 0
    with tf.Session() as sess:
        for iter_cur in range(config.iter_num):
            print('====================================iter ' + str(iter_cur + 1) + ' =====================================')
            if (iter_cur == 0):
                sess.run(tf.global_variables_initializer())
                sess.run(tf.local_variables_initializer())
                print('var initialized')

            print('==================================== pretraining =====================================')
            with open(config.result_dir, "r") as csvfile:
                reader = csv.reader(csvfile)
                result = list(reader)
            for i in range(config.pretrain_epoch):
                rand_label=result[i%64][:config.node_num]
                rand_label=list(map(int,rand_label))
                _,score=sess.run([pre.pretrain_step,scores], feed_dict={input: inputs, num_service: num,label:rand_label})
            print('==================================== pretrain completed =====================================')
            print('==================================== reinforcement learning =====================================')
            pointer = []
            for rl in range(config.rl_epoch):
                pos_list, probs = sess.run([pos, actor.prob],feed_dict={input: inputs, num_service: num})
                reward_list = []
                real_reward=[]
                for _ in range(config.sample_num):
                    point = []
                    for l in range(config.node_num):
                        point.append(pos_list[_][l])
                    f = calattr.receive(pos_list[_])  # i+1
                    evaluations_number = evaluations_number + 1
                    point.append(f)
                    pointer.append(point)
                    real_reward.append(-f)
                    reward_list.append(-f)
                    if (min > -f):
                            min = -f
                            po=pos_list[_].astype(str)
                            fo = open(config.temp_best_dir, "a")
                            fo.write(' '.join(po) + ' ' + str(-min) + ' ' + str(time.time() - start) + ' '+ str(evaluations_number) + '\n')
                            fo.close()

                mean=np.mean(reward_list)
                reward_list=reward_list-mean

                grads, _ = sess.run(
                        [optimize.grads, optimize.train_step],
                        feed_dict={input: inputs, reward: reward_list, num_service: num})

            def takeF(elem):
                return elem[-1]
            with open(config.result_dir, "r") as csvfile:
                reader = csv.reader(csvfile)
                before_result = list(reader)
                for q in range(config.best_num):
                    b_re = before_result[q]
                    int_line = list(map(int, b_re[:config.node_num]))
                    int_line.append(float(b_re[-1]))
                    pointer.append(int_line)
            pointer = list(set([tuple(t) for t in pointer]))
            pointer.sort(key=takeF, reverse=True)
            pointer = pointer[:config.best_num]

            csvfile = open(config.result_dir, "w", newline="")
            writer = csv.writer(csvfile)
            writer.writerows(pointer)
            csvfile.close()
            print("WRITED IN SUIJI CSV !")
            print('==================================== reinforcement completed =====================================')

if __name__ == "__main__":
    node = '10'
    config, _ = get_config()
    config.node_num = int(node)
    rootdir = 'testmore/'+node
    calattr = Calattr()
    training_set = SC_DataGenerator()
    config.result_dir = 'pretrain/result.csv'

    for num in range(5):
        for listFile in os.listdir(rootdir):
            evaluations_number = 0
            print(listFile)
            config.ist_nodeset = node + '/' + listFile

            config.temp_best_dir = 'testlog/new/calattar'+node+'_'+listFile+'_'+str(num)+'.txt'

            calattr.init(config.node_num, config.train_from, config.ist_nodeset)
            generate.generate_data(calattr,config)
            inputs, num, count = training_set.train_batch(config.input_dimension, config.train_from,
                config.ist_nodeset,
                config,
                calattr
            )
            config.all_node_num = count
            main(config, calattr, inputs, num, evaluations_number)
