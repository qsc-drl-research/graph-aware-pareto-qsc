import numpy as np
import os
import random
def calaulate(filepath, nodenum, filenum,n):
    qos = []
    times = []
    evaluations = []
    qos_mean = 0
    qos_var = 0
    time_mean = 0
    eval_mean = 0

    for i in range(0, 5):
        filename = filepath + '/calattar' + str(nodenum) + '_' + str(filenum) + '_' + str(i) + '.txt'

        file = open(filename, 'r')
        lines = file.readlines()
        lastline = lines[-1]
        parts = lastline.strip().split()

        if len(parts) > nodenum:
            qos_value = float(parts[nodenum])
            qos.append(qos_value)

        if len(parts) > nodenum + 1:
            time_val = float(parts[nodenum + 1])
            times.append(time_val)

        if len(parts) > nodenum + 2:
            eval_val = float(parts[nodenum + 2])
            evaluations.append(eval_val)

    if qos:
        qos_mean = np.mean(qos)
        qos_var = np.var(qos)

    if times:
        time_mean = np.mean(times)

    if evaluations:
        eval_mean = np.mean(evaluations)

    return qos_mean, qos_var, time_mean, eval_mean


def main():
    filepath = './testlog/new'
    nodenum_list = [10,30,50,70,90,100]
    filenum_list = [1,5,7,4,5,3]

    for n in range(6):
        nodenum = nodenum_list[n]
        filenum = filenum_list[n]
        qos_mean, qos_var, time_mean, eval_mean = calaulate(filepath,nodenum,filenum,n)

        print(f"Node {nodenum}: Mean = {qos_mean}, Variance = {qos_var}, Avg Time (s) = {time_mean}, Avg evaluation number = {eval_mean} \n")

if __name__ == "__main__":

    main()

