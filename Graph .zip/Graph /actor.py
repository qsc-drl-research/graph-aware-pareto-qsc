
import tensorflow as tf
distr = tf.contrib.distributions

class Actor(tf.keras.Model): #Defines the Actor as a Keras Model (neural network)
        def __init__(self, config):
                super(Actor, self).__init__()
                with tf.variable_scope('actor'):
                    self.config=config
                    self.input_dimension = config.input_dimension  # Number of service quality categories  5
                    self.initializer = tf.contrib.layers.xavier_initializer()  # variables initializer of neural network weights
                    self.node_num=config.node_num
                    self.sample_num=config.sample_num
                    self.C=config.C
                    self.all_node_num=config.all_node_num
                    print(self.all_node_num)

        def call(self,inputs,num_service):#inputs: Current state (all candidate services with their QoS values)

            with tf.variable_scope('actor'):
                self.log_softmaxs = []
                self.positions = []

                layer2 = tf.layers.dense(inputs,128,name='fn1',activation=tf.nn.tanh)

                layer3 = tf.layers.dense(layer2,self.all_node_num,name='fn2')

                scores = tf.squeeze(layer3)

                scores = self.C*tf.nn.tanh(scores)

                before = 0
                for k in range(self.node_num):
                    # Extract scores for current task's candidates
                    temp_choose = tf.slice(scores, [before], [num_service[k]])  # temp_choose:[temp_sequence]

                    if(k==5):
                        self.prob = tf.nn.softmax(temp_choose) # Save for monitoring


                    prob = distr.Categorical(temp_choose)

                    position = prob.sample(self.sample_num)

                    # Calculate log probability for policy gradient
                    log_softmax = prob.log_prob(position)

                    # Store results
                    self.log_softmaxs.append(log_softmax)
                    # Calculate log probability of the sampled action

                    self.positions.append(position)

                    # Move to next task's candidates
                    before = before + num_service[k] # Move to next task

                # Sum log probabilities across all tasks
                self.log_softmax = tf.reduce_sum(self.log_softmaxs, axis=0)

                return tf.transpose(self.positions), self.log_softmax,scores



