# -*- coding: utf-8 -*-

import tensorflow as tf
from newactor import Actor
from newoptimizer import Optimize
from sc_dataset import SC_DataGenerator
from config import get_config
from calattr import Calattr
import calattr as calattr_module
from tqdm import tqdm
import numpy as np
import datetime
import os
def main():

    # Get running configuration
    config, _ = get_config()

    os.makedirs("result", exist_ok=True)
    node_list = [30, 50, 70, 90, 100]
    num_reps = 5
    for node in node_list:
        for rep in range(num_reps):
            print("\n=== node %d, rep %d/%d ===" % (node, rep + 1, num_reps))
            tf.reset_default_graph()
            config.node_num = node
            calattr_module.config.node_num = node

            input = tf.placeholder(tf.float32, [None, config.input_dimension], name="input_raw")
            reward=tf.placeholder(tf.float32,[config.sample_num],name="reward")
            num_service = tf.placeholder(tf.int32, [config.node_num], name="num_service")

            global_step = tf.Variable(0, trainable=False, name="global_step")

            actor = Actor(config)
            optimize = Optimize(config, global_step)

            training_set = SC_DataGenerator()
            position, softmax = actor(input,num_service)
            optimize.build_optim(reward, softmax)

            with tf.Session() as sess:
                sess.run(tf.global_variables_initializer())
                sess.run(tf.local_variables_initializer())
                device = '/cpu:0'
                with tf.device(device):
                    min = 100

                    data_dir = os.path.join('data', str(config.node_num))
                    conf_dir = os.path.join(data_dir, 'conf.xml')
                    inputs, num = training_set.train_batch(config.input_dimension, data_dir)

                    calattr = Calattr()
                    calattr.init(conf_dir, data_dir)
                    starttime = datetime.datetime.now()

                    for i in tqdm(range(config.nb_epoch)):
                        pos_list=sess.run(position, feed_dict={input: inputs,num_service:num})
                        reward_list=[]
                        for _ in range(config.sample_num):
                            f = calattr.receive(pos_list[_])#i+1
                            reward_list.append(-f)
                            if(min>-f):
                                min=-f
                                po = pos_list[_].astype(str)
                                fo = open(os.path.join("result", str(config.node_num) + "_rep" + str(rep) + ".txt"),
                                          "a")
                                curtime = datetime.datetime.now()
                                time = (curtime - starttime).total_seconds()
                                row = [int(x) for x in pos_list[_]] + [-min, time]
                                fo.write(str(row) + '\n')
                                print('calattar updated')
                                fo.close()
                        sess.run(optimize.train_step1,feed_dict={input: inputs,reward:reward_list,num_service:num})
                    print("Training COMPLETED !")


if __name__ == "__main__":
    #tfe.enable_eager_execution()
    main()