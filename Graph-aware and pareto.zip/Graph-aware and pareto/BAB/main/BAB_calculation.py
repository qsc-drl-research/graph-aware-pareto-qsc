import ast
import numpy as np
import os


def calculate_mean_variance(filepath, node_num, num_reps):
    rewards = []
    times = []
    evaluations = []

    for rep in range(1, num_reps + 1):
        result_file = os.path.join(filepath, f"{node_num}_rep{rep}.txt")

        # Check if the result file exists
        if os.path.exists(result_file):
            with open(result_file, "r") as f:
                lines = f.readlines()
                last_line = lines[-1]  # Get the last line in the file

                # Extract the reward
                try:

                    parts = last_line.strip().split(']')[-1].split()
                    reward = float(parts[-3])
                    time_val = float(parts[-2])
                    eval_val = float(parts[-1])

                    rewards.append(reward)
                    times.append(time_val)
                    evaluations.append(eval_val)

                except (ValueError, SyntaxError, IndexError):
                    print(f"Error parsing reward from line: {last_line}")
                    continue
        else:
            print(f"Warning: Result file for node {node_num}, repetition {rep} does not exist.")

    # Calculate the mean and variance of the rewards for this node across all repetitions
    if rewards:
        mean_reward = np.mean(rewards)
        var_reward = np.var(rewards)
        time_mean = np.mean(times)
        eval_mean = np.mean(evaluations)

        # Print mean and variance with 2 decimal places
        print(f"Node {node_num}: Mean = {mean_reward}, Variance = {var_reward}, Avg Time (s) = {time_mean}, Avg evaluation number = {eval_mean}")
        return mean_reward, var_reward
    else:
        print(f"No valid rewards found for node {node_num}.")
        return None, None


def main():
    filepath = './InBranchresult'
    node_numbers = [10, 30, 50, 70, 90, 100]

    # Ask for the number of repetitions
    num_reps = 5

    # Calculate and display mean and variance for each node
    for node_num in node_numbers:
        calculate_mean_variance(filepath, node_num, num_reps)


if __name__ == "__main__":
    main()
