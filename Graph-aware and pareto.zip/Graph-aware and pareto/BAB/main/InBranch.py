import calattr
import numpy
import numpy as np
import time
import os
import csv

NODE_LIST = [10, 30, 50, 70, 90, 100]
GRAPH_LIST = [1, 5, 7, 4, 5, 3]
REP_NUM = 5

calattr = calattr.Calattr()

def Get_numservice(f):
    num_service = []
    f.readline()
    line = f.readline()
    candidates_c = line.split()
    candidates = []
    for index in range(len(candidates_c)):
        candidates.append(candidates_c[index])
    for candidate in candidates:
        num = 0
        f1 = open('julei_result/' + candidate + '.txt')
        line1 = f1.readline()
        while line1:
            num = num + 1
            line1 = f1.readline()
        num_service.append(num)
    return num_service

def translateDNA(x,num_service):
    x_out=[]
    print(num_service)
    for i in range(len(num_service)):
        x_out.append(np.maximum(int(
            np.floor(x[i] * num_service[i]-0.0001)
        ),0))
    return x_out

def branch(nodeset ,number,NODE_NUM,rep,startTime):

    calattr.init(os.path.join('test', str(NODE_NUM)), number, NODE_NUM)
    inition = np.zeros(NODE_NUM+1)
    inition_one=np.zeros(NODE_NUM,numpy.int8)
    initionsum = np.random.random(size=(1,NODE_NUM))
    inition_one[0:NODE_NUM] = translateDNA(initionsum[0],nodeset)
    inition[0:NODE_NUM] =inition_one[0:NODE_NUM]
    inition[-1]=calattr.receive(inition_one[0:NODE_NUM])
    evalation=0;
    for i in range(len(nodeset)):
        nodeset_fu = []
        for p in range(len(nodeset)):
            nodeset_fu.append(int(nodeset[p]))
        for j in range(nodeset[i]):
            evalation=evalation+1
            print("the j is%d"%j)
            inition_two =np.zeros(NODE_NUM+3)
            inition_three =np.zeros(NODE_NUM+1,numpy.int8)
            for v in range(len(inition)):
                inition_two[v]=inition[v]
            inition_two[i]=j
            for m in range(len(inition_three)):
                inition_three[m]=(int)(inition_two[m])
            inition_two[-3]=(calattr.receive(inition_three[0:NODE_NUM]))
            print("the inition :"+str(inition))
            print("the inition_two ;"+str(inition_two))
            if(float(inition_two[-3])>float(inition[-1])):
                timePrice = time.time()-startTime
                for n in range(len(inition)):
                    inition[n]=inition_two[n]
                pathResult = os.path.join('InBranchresult', '%d_rep%d.txt' % (NODE_NUM, rep))
                try:
                    fobj = open(pathResult, 'a')
                except IOError:
                    print('file open error:')
                else:
                    fobj.write(str(inition_three[0:NODE_NUM]))
                    fobj.write(" ")
                    fobj.write(str(inition_two[-3]))
                    fobj.write(" ")
                    fobj.write(str(timePrice))
                    fobj.write(" ")
                    fobj.write(str(evalation))
                    fobj.write('\n')
                    print("insert ok")
                    fobj.close()

            else:
                print("New result did not improve on the current best, skipping")
                continue
    return inition
for idx in range(len(NODE_LIST)):
    NODE_NUM = NODE_LIST[idx]
    number = GRAPH_LIST[idx]
    for rep in range(1, REP_NUM + 1):
        startTime = time.time()
        path = os.path.join('test', str(NODE_NUM), str(number), 'nodeSet.txt')
        f = open(path)
        nodse1 = Get_numservice(f)
        f.close()
        print(nodse1)
        a = branch(nodse1, number, NODE_NUM, rep, startTime)