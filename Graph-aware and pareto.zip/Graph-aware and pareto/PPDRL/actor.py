
import tensorflow as tf
distr = tf.contrib.distributions

class Actor(tf.keras.Model): #Defines the Actor as a Keras Model (neural network)
        def __init__(self, config):
                super(Actor, self).__init__()
                with tf.variable_scope('actor'):
                    self.config=config
                    self.input_dimension = config.input_dimension  # Number of service quality categories  5
                    self.initializer = tf.contrib.layers.xavier_initializer()  # variables initializer of neural network weights
                    self.node_num=config.node_num
                    self.sample_num=config.sample_num
                    self.C=config.C
                    self.all_node_num=config.all_node_num
                    print(self.all_node_num)

        def call(self,inputs,num_service):
            with tf.variable_scope('actor'):
                self.log_softmaxs = []
                self.positions = []

                layer2 = tf.layers.dense(inputs,128,name='fn1',activation=tf.nn.tanh)

                layer3 = tf.layers.dense(layer2,self.all_node_num,name='fn2')

                scores = tf.squeeze(layer3)  # removed unnecessary dimensions
                scores = self.C*tf.nn.tanh(scores)

                before = 0
                for k in range(self.node_num):
                    temp_choose = tf.slice(scores, [before], [num_service[k]])  # temp_choose:[temp_sequence]

                    if(k==5):
                        self.prob = tf.nn.softmax(temp_choose) # Save for monitoring

                    prob = distr.Categorical(temp_choose) # Categorical Distribution: Converts scores to probabilities

                    position = prob.sample(self.sample_num)

                    log_softmax = prob.log_prob(position)
                    self.log_softmaxs.append(log_softmax)

                    self.positions.append(position)

                    before = before + num_service[k] # Move to next task
                self.log_softmax = tf.reduce_sum(self.log_softmaxs, axis=0)

                return tf.transpose(self.positions), self.log_softmax,scores





