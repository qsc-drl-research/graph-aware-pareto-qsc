import numpy as np
import linecache
import tensorflow as tf


class SC_DataGenerator(object):
    np.random.seed(1)
    def gen_instance(self,dimension, f):
        num_service = []
        service1 = []
        f.readline()
        line = f.readline()
        candidates_c = line.split(' ')
        candidates = []
        for index in range(len(candidates_c)):
            candidates.append(candidates_c[index])
        for candidate in candidates:
            num = 0
            f1 = open('服务名聚类最终结果/'+candidate+'.txt')
            line1 = f1.readline()
            while line1:
                num = num+1
                line1 = f1.readline()
            num_service.append(num)
        return num_service


    def train_batch(self, dimension, position, i):
        f = open(position + '/' + i + '/nodeSet.txt')
        input_ = np.random.randn(1, 16)
        num = self.gen_instance(dimension, f)
        count = 0
        for i in num:
            count = count+i
        return input_, num, count

if __name__ == "__main__":
    sc = SC_DataGenerator()
    input_,num,count = sc.train_batch(5,'test',12)
    print('input: ',input_)
    print('num: ',num)
    print('count: ',count)

