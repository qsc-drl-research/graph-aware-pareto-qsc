import ast
import numpy as np
import os


def calculate_mean_variance(filepath, node_num, num_reps):
    rewards = []
    times = []
    evaluations = []

    for rep in range(num_reps):
        result_file = os.path.join(filepath, f"{node_num}_rep{rep}.txt")

        # Check if the result file exists
        if os.path.exists(result_file):
            with open(result_file, "r") as f:
                lines = f.readlines()
                last_line = lines[-1]  # Get the last line in the file

                # Extract the reward from the second-to-last value in the last line
                try:
                    row = ast.literal_eval(last_line.strip())
                    reward = float(row[-3])
                    time_val = float(row[-2])
                    eval_val = float(row[-1])

                    print(f"Repetition {rep + 1}: Reward = {reward}")  # Print reward for each repetition
                    rewards.append(reward)
                    times.append(time_val)
                    evaluations.append(eval_val)

                except (ValueError, SyntaxError, IndexError):
                    print(f"Error parsing reward from line: {last_line}")
                    continue
        else:
            print(f"Warning: Result file for node {node_num}, repetition {rep} does not exist.")

    # Calculate the mean and variance of the rewards for this node across all repetitions
    if rewards:
        mean_reward = np.mean(rewards)
        var_reward = np.var(rewards)
        time_mean = np.mean(times)
        eval_mean = np.mean(evaluations)

        # Print mean and variance with 2 decimal places
        print(f"Node {node_num}: Mean = {mean_reward}, Variance = {var_reward}, Avg Time (s) = {time_mean}, Avg evaluation number = {eval_mean}")
        return mean_reward, var_reward
    else:
        print(f"No valid rewards found for node {node_num}.")
        return None, None


def main():
    # Filepath where the result files are stored
    filepath = './result'
    node_numbers = [10, 30, 50, 70, 90, 100]

    # Ask for the number of repetitions
    num_reps = int(input("Enter the number of repetitions per node: "))

    # Calculate and display mean and variance for each node
    for node_num in node_numbers:
        calculate_mean_variance(filepath, node_num, num_reps)


if __name__ == "__main__":
    main()
