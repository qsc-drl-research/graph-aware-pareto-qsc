import newga
import time
import numpy as np
import random
import csv
import calattr
import generate as ge

NODE_GRAPH = {10: 1, 30: 5, 50: 7, 70: 4, 90: 5, 100: 3}
NUM_REPS = 5

for NODE_NUM, graph_num in NODE_GRAPH.items():
  for rep in range(NUM_REPS):
        timstart =time.time()

        ge.calattr.init('test/%d' % NODE_NUM, graph_num, NODE_NUM)

        path ='test/'+str(NODE_NUM)+'/%d/nodeSet.txt'%graph_num
        f = open(path)
        num_service = ge.Get_numservice(f)
        result = []
        for i in range(64):
            print(i)
            pointer = []
            for j in range(NODE_NUM):
                point = random.randint(0, num_service[j] - 1)
                pointer.append(point)
            f = ge.calattr.receive(pointer)
            pointer.append(f)
            result.append(pointer)


        result = result[:64]
        csvfile = open('init_data/init_data.csv', "w", newline="")
        writer = csv.writer(csvfile)
        writer.writerows(result)
        csvfile.close()

        a, calNum = newga.GA(graph_num, num_service, timstart, NODE_NUM, rep)
        #返回结果
        timeresult = time.time()-timstart
        print(NODE_NUM,a,calNum,timeresult)


