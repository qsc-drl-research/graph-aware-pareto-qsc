import numpy as np
import linecache
import tensorflow as tf
from pareto_pruning import ParetoSkylinePruner
import os

# This file loads the service composition problem structure to Define the network architecture.
class SC_DataGenerator(object):
    np.random.seed(1)

    def gen_instance(self,dimension, f, load_qos=True):
        num_service = []
        workflow_data = {}

        f.readline()
        line = f.readline()
        candidates_c = line.split(' ')
        candidates = []
        for index in range(len(candidates_c)):
            candidates.append(candidates_c[index])

        task_id = 0
        for candidate in candidates:
            num = 0
            service_ids = []  # Store service IDs for this task
            f1 = open('服务名聚类最终结果/' + candidate + '.txt')
            line1 = f1.readline()
            while line1:
                num = num+1
                if load_qos:
                    atom = line1.split(':')[0]
                    service_ids.append(int(atom))
                line1 = f1.readline()
            f1.close()
            num_service.append(num)

            # Load QoS values if requested
            if load_qos and service_ids:
                qos_list = self.load_qos_values(service_ids)

                # Structure data for pareto pruning
                candidates_with_qos = []
                for idx, qos in enumerate(qos_list):
                    candidate_data = {
                        'original_index': idx,
                        'service_id': qos['id'],
                        'response_time': qos['response_time'],
                        'cost': qos['cost'],
                        'availability': qos['availability'],
                        'reliability': qos['reliability'],
                        'success_rate': qos['successability'],
                        'throughput': qos['throughput']
                    }
                    candidates_with_qos.append(candidate_data)

                workflow_data[task_id] = candidates_with_qos

            task_id += 1

        return num_service, workflow_data

    def train_batch(self, dimension, position,  i, use_pareto_pruning=True):  #dimension:服务质量类别数

        f = open(position + '/' + i + '/nodeSet.txt', 'r', encoding='utf-8')

        # Generate sc instance with QoS values
        input_ = np.random.randn(1, 16)
        num_original, workflow_data = self.gen_instance(dimension, f, load_qos=True)
        f.close()

        # Apply Pareto Skyline Pruning if enabled
        if use_pareto_pruning:
            print("=" * 70)
            print("APPLYING PARETO SKYLINE PRUNING...")
            print("=" * 70)

            pruner = ParetoSkylinePruner(enable_logging=True)
            pruning_result = pruner.prune_workflow_candidates(workflow_data)

            pruned_candidates = pruning_result['pruned_data']
            index_mappings = pruning_result['index_mappings']
            pruning_stats = pruning_result['statistics']

            print(pruner.get_statistics_summary())

            stats_dir = 'testlog/pruning'
            if not os.path.exists(stats_dir):
                os.makedirs(stats_dir)
            stats_file = os.path.join(stats_dir, f'pruning_stats_{i.replace("/", "_")}.txt')
            pruner.save_statistics(stats_file)
            print(f"Pruning statistics saved to: {stats_file}")

            num = []
            count = 0
            for task_id in sorted(pruned_candidates.keys()):
                num_skyline = len(pruned_candidates[task_id])
                num.append(num_skyline)
                count += num_skyline

            print(f"Action space reduced from {sum(num_original)} to {count} candidates")
            print("=" * 70)

        else:
            # No pruning - use original data
            print("Pareto Skyline Pruning: DISABLED")
            num = num_original
            count = sum(num)
            pruned_candidates = workflow_data
            index_mappings = {task_id: {i: i for i in range(len(candidates))}
                              for task_id, candidates in workflow_data.items()}
            pruning_stats = None

        return input_, num, count, pruned_candidates, index_mappings, pruning_stats

    def calculate_cost(self, response_time, availability, throughput, successability, reliability,
                       max_time, max_avail, max_throu, max_success, max_reli):
        """
        Calculate cost metric using same formula as calattr.py GetPrice()
        Cost is a weighted combination of all 5 QoS metrics (normalized)
        """
        cost = (0.2 * (response_time / max_time) +
                0.2 * (availability / max_avail) +
                0.2 * (throughput / max_throu) +
                0.2 * (successability / max_success) +
                0.2 * (reliability / max_reli))
        return cost

    def load_qos_values(self, service_ids):

        qos_data = []

        # First pass: Find max values for cost calculation
        temp_data = []
        for service_id in service_ids:
            try:
                # QWS_Dataset.txt format: id,responseTime,availability,throughput,successability,reliability
                line = linecache.getline('QWS_Dataset.txt', service_id)
                if line:
                    values = line.strip().split(',')
                    temp_data.append({
                        'id': int(values[0]),
                        'response_time': float(values[1]),
                        'availability': float(values[2]),
                        'throughput': float(values[3]),
                        'successability': float(values[4]),
                        'reliability': float(values[5])
                    })
            except Exception as e:
                print(f"Error loading service {service_id}: {e}")
                continue

        # Calculate max values for cost normalization
        if temp_data:
            max_time = max([d['response_time'] for d in temp_data])
            max_avail = max([d['availability'] for d in temp_data])
            max_throu = max([d['throughput'] for d in temp_data])
            max_success = max([d['successability'] for d in temp_data])
            max_reli = max([d['reliability'] for d in temp_data])

            # Second pass: Calculate cost for each service
            for data in temp_data:
                cost = self.calculate_cost(
                    data['response_time'], data['availability'], data['throughput'],
                    data['successability'], data['reliability'],
                    max_time, max_avail, max_throu, max_success, max_reli
                )
                data['cost'] = cost
                qos_data.append(data)

        return qos_data


if __name__ == "__main__":

    print("Testing SC_DataGenerator with Pareto Skyline Pruning...")
    print()

    sc = SC_DataGenerator()

    # Test WITH pruning
    print("TEST 1: WITH Pareto Skyline Pruning")
    print("-" * 70)
    input_, num, count, pruned_candidates, index_mappings, stats = sc.train_batch(
        5, 'test', '10/2', use_pareto_pruning=True
    )
    print(f'\nResults:')
    print(f'  Input shape: {input_.shape}')
    print(f'  Num candidates per task (after pruning): {num}')
    print(f'  Total count (after pruning): {count}')
    print(f'  Number of tasks: {len(pruned_candidates)}')
    print()

    # Test WITHOUT pruning (for comparison)
    print("\nTEST 2: WITHOUT Pareto Skyline Pruning")
    print("-" * 70)
    input_, num, count, pruned_candidates, index_mappings, stats = sc.train_batch(
        5, 'test', '10/2', use_pareto_pruning=False
    )
    print(f'\nResults:')
    print(f'  Input shape: {input_.shape}')
    print(f'  Num candidates per task (no pruning): {num}')
    print(f'  Total count (no pruning): {count}')
    print(f'  Number of tasks: {len(pruned_candidates)}')


