# Create a test script: test_verification.py

from calattr import Calattr
from config import get_config

# Initialize
config, _ = get_config()
config.node_num = 10
calattr = Calattr()
calattr.init(10, 'test', '10/1')

# Example log line taken from a PPDRL+Graph+Pareto training run (node_num=10).


line = "2 108 4 0 1 0 0 5 9 0 0.320212120438802 4.4020068645477295 19229"
parts = line.strip().split()

positions = [int(parts[i]) for i in range(10)]  # First 10 values
logged_reward = float(parts[10])  # 11th value

print(f"Positions: {positions}")
print(f"Logged reward: {logged_reward}")

calculated_reward = calattr.receive(positions)

print(f"Calculated reward: {calculated_reward}")
print(f"Match: {abs(calculated_reward - logged_reward) < 0.0001}")  # Should be True

# Expected output:
# Positions: [2, 108, 4, 0, 1, 0, 0, 5, 9, 0]
# Logged reward: 0.320212120438802
# Calculated reward: 0.320212120438802
# Match: True ✅