from calattr import Calattr
import random
import csv
from config import get_config
from sc_dataset import SC_DataGenerator


def Get_numservice(f):
    """Get number of candidates per task from nodeSet.txt"""
    num_service = []
    f.readline()  # Skip first line
    line = f.readline()
    candidates_c = line.split(' ')
    candidates = []
    for index in range(len(candidates_c)):
        candidates.append(candidates_c[index])

    for candidate in candidates:
        num = 0
        f1 = open('服务名聚类最终结果/' + candidate + '.txt')
        line1 = f1.readline()
        while line1:
            num = num + 1
            line1 = f1.readline()
        num_service.append(num)
    return num_service


def generate_data(calattr, config):
    print("\n" + "=" * 70)
    print("GENERATING INITIAL TRAINING DATA")
    print("=" * 70)

    # Load data with Pareto pruning
    training_set = SC_DataGenerator()
    _, num_skyline, _, pruned_candidates, index_mappings, pruning_stats = training_set.train_batch(
        config.input_dimension,
        config.train_from,
        config.ist_nodeset,
        use_pareto_pruning=config.use_pareto_pruning
    )

    # Print pruning info
    if pruning_stats:
        print(f"Using skyline candidates: {pruning_stats.get('total_skyline_candidates', 'N/A')}")
        print(f"Original candidates: {pruning_stats.get('total_original_candidates', 'N/A')}")

        # Try different possible key names
        reduction = (pruning_stats.get('average_reduction_percentage') or
                     pruning_stats.get('reduction_percentage') or
                     pruning_stats.get('avg_reduction') or
                     pruning_stats.get('average_reduction'))

        if reduction is not None:
            print(f"Reduction: {reduction:.2f}%")
    else:
        print(f"Using all candidates (pruning disabled): {sum(num_skyline)}")

    #Generate samples using skyline candidates
    result = []
    for i in range(config.init_gen_num):
        if (i + 1) % 10000 == 0:
            print(f"  Generated {i + 1}/{config.init_gen_num} samples...")

        # Generate random positions from SKYLINE candidates
        skyline_positions = []
        for j in range(config.node_num):
            # Pick random position from skyline (0 to num_skyline[j]-1)
            skyline_pos = random.randint(0, num_skyline[j] - 1)
            skyline_positions.append(skyline_pos)

        # Map skyline positions to original positions for evaluation
        original_positions = []
        for task_id in range(config.node_num):
            skyline_pos = skyline_positions[task_id]
            original_pos = index_mappings[task_id][skyline_pos]
            original_positions.append(original_pos)

        # Evaluate using ORIGINAL positions
        f = calattr.receive(original_positions)

        # Store SKYLINE positions (what Actor will see during training)
        skyline_positions.append(f)
        result.append(skyline_positions)

    #Sort by fitness (best first) and take top 64
    def takeF(elem):
        return elem[-1]

    result.sort(key=takeF, reverse=True)
    result = result[:config.best_num]

    #Save to CSV
    csvfile = open(config.result_dir, "w", newline="")
    writer = csv.writer(csvfile)
    writer.writerows(result)
    csvfile.close()
