# Create: check_bounds.py

# Read your log file
log_file = "testlog/new/calattar10_1_0.txt"

# Read nodeSet.txt to get candidate counts
from generate import Get_numservice

f = open("test/10/1/nodeSet.txt")
num_service = Get_numservice(f)

print(f"Candidate counts per task: {num_service}")

# Check each line in log
with open(log_file, 'r') as f:
    for line_num, line in enumerate(f, 1):
        parts = line.strip().split()
        positions = [int(parts[i]) for i in range(10)]

        # Check each position is within bounds
        all_valid = True
        for task_id, pos in enumerate(positions):
            if pos >= num_service[task_id] or pos < 0:
                print(f"❌ Line {line_num}: Task {task_id} position {pos} out of bounds [0, {num_service[task_id] - 1}]")
                all_valid = False

        if all_valid and line_num % 100 == 0:
            print(f"✅ Line {line_num}: All positions valid")

print("\nVerification complete!")

