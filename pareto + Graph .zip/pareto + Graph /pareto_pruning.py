import numpy as np


class ParetoSkylinePruner:

    def __init__(self, enable_logging=True):


        self.enable_logging = enable_logging
        self.statistics = {
            'total_original': 0,
            'total_pruned': 0,
            'total_skyline': 0,
            'per_task_stats': []
        }

    def dominates(self, service_a, service_b):

        a_rt = service_a['response_time']
        a_cost = service_a['cost']
        a_avail = service_a['availability']
        a_reli = service_a['reliability']
        a_succ = service_a['success_rate']
        a_throu = service_a['throughput']

        b_rt = service_b['response_time']
        b_cost = service_b['cost']
        b_avail = service_b['availability']
        b_reli = service_b['reliability']
        b_succ = service_b['success_rate']
        b_throu = service_b['throughput']

        better_or_equal = (
                a_rt <= b_rt and  # Minimize
                a_cost <= b_cost and  # Minimize
                a_avail >= b_avail and  # Maximize
                a_reli >= b_reli and  # Maximize
                a_succ >= b_succ and  # Maximize
                a_throu >= b_throu  # Maximize
        )

        strictly_better = (
                a_rt < b_rt or  # Minimize
                a_cost < b_cost or  # Minimize
                a_avail > b_avail or  # Maximize
                a_reli > b_reli or  # Maximize
                a_succ > b_succ or  # Maximize
                a_throu > b_throu  # Maximize
        )

        return better_or_equal and strictly_better

    def sort_filter_skyline(self, candidates):

        if not candidates:
            return [], {}, {'original': 0, 'skyline': 0, 'pruned': 0, 'reduction_%': 0.0}

        # SORT by response time (ascending - lower is better)
        sorted_candidates = sorted(candidates, key=lambda x: x['response_time'])

        #FILTER - Build skyline set
        skyline = []

        for candidate in sorted_candidates:
            is_dominated = False
            services_to_remove = []

            # Compare with current skyline services
            for i, skyline_service in enumerate(skyline):
                if self.dominates(skyline_service, candidate):
                    # Candidate is dominated by existing skyline service
                    is_dominated = True
                    break
                elif self.dominates(candidate, skyline_service):
                    # Candidate dominates existing skyline service
                    services_to_remove.append(i)

            # If not dominated, add to skyline
            if not is_dominated:
                # Remove dominated services from skyline
                for idx in reversed(services_to_remove):
                    skyline.pop(idx)
                # Add new non-dominated service
                skyline.append(candidate)

        # Create index mapping
        index_mapping = {}
        for new_idx, service in enumerate(skyline):
            index_mapping[new_idx] = service['original_index']

        # Collect statistics
        original_count = len(candidates)
        skyline_count = len(skyline)
        pruned_count = original_count - skyline_count
        reduction_pct = (pruned_count / original_count * 100) if original_count > 0 else 0.0

        stats = {
            'original': original_count,
            'skyline': skyline_count,
            'pruned': pruned_count,
            'reduction_%': reduction_pct
        }

        return skyline, index_mapping, stats

    def prune_workflow_candidates(self, workflow_data):

        pruned_data = {}
        index_mappings = {}
        per_task_stats = []

        for task_id, candidates in workflow_data.items():
            skyline, mapping, stats = self.sort_filter_skyline(candidates)

            pruned_data[task_id] = skyline
            index_mappings[task_id] = mapping

            # Log statistics
            if self.enable_logging:
                task_stat = {
                    'task_id': task_id,
                    'original_count': stats['original'],
                    'skyline_count': stats['skyline'],
                    'pruned_count': stats['pruned'],
                    'reduction_%': stats['reduction_%']
                }
                per_task_stats.append(task_stat)

        # Calculate overall statistics
        total_original = sum([s['original_count'] for s in per_task_stats])
        total_skyline = sum([s['skyline_count'] for s in per_task_stats])
        total_pruned = total_original - total_skyline
        avg_reduction = (total_pruned / total_original * 100) if total_original > 0 else 0.0

        overall_stats = {
            'total_original_candidates': total_original,
            'total_skyline_candidates': total_skyline,
            'total_pruned_candidates': total_pruned,
            'average_reduction_%': avg_reduction,
            'per_task_statistics': per_task_stats
        }

        # Update instance statistics
        self.statistics = overall_stats

        return {
            'pruned_data': pruned_data,
            'index_mappings': index_mappings,
            'statistics': overall_stats
        }

    def get_statistics_summary(self):
        stats = self.statistics

        summary = "=" * 70 + "\n"
        summary += "PARETO SKYLINE PRUNING STATISTICS\n"
        summary += "=" * 70 + "\n"
        summary += f"Total Original Candidates:  {stats['total_original_candidates']}\n"
        summary += f"Total Skyline Candidates:   {stats['total_skyline_candidates']}\n"
        summary += f"Total Pruned Candidates:    {stats['total_pruned_candidates']}\n"
        summary += f"Average Reduction:          {stats['average_reduction_%']:.2f}%\n"
        summary += "-" * 70 + "\n"
        summary += "Per-Task Breakdown:\n"
        summary += "-" * 70 + "\n"

        for task_stat in stats['per_task_statistics']:
            summary += f"Task {task_stat['task_id']}: "
            summary += f"{task_stat['original_count']} → {task_stat['skyline_count']} "
            summary += f"({task_stat['reduction_%']:.1f}% reduction)\n"

        summary += "=" * 70 + "\n"

        return summary

    def save_statistics(self, filepath):
        with open(filepath, 'w') as f:
            f.write(self.get_statistics_summary())


# Convenience function for quick usage
def apply_pareto_pruning(workflow_data, enable_logging=True):

    pruner = ParetoSkylinePruner(enable_logging=enable_logging)
    result = pruner.prune_workflow_candidates(workflow_data)
    return result

if __name__ == "__main__":
    print("Pareto Skyline Pruning Module")
    print("Testing with sample data...")

    sample_workflow = {
        'task_1': [
            {'original_index': 0, 'service_id': 1, 'response_time': 100, 'cost': 10,
             'availability': 95, 'reliability': 90, 'success_rate': 85, 'throughput': 50},
            {'original_index': 1, 'service_id': 2, 'response_time': 120, 'cost': 8,
             'availability': 93, 'reliability': 88, 'success_rate': 80, 'throughput': 45},
            {'original_index': 2, 'service_id': 3, 'response_time': 90, 'cost': 12,
             'availability': 97, 'reliability': 92, 'success_rate': 90, 'throughput': 55},
            {'original_index': 3, 'service_id': 4, 'response_time': 150, 'cost': 15,
             'availability': 85, 'reliability': 80, 'success_rate': 75, 'throughput': 40},  # Dominated
        ],
        'task_2': [
            {'original_index': 0, 'service_id': 5, 'response_time': 80, 'cost': 9,
             'availability': 96, 'reliability': 91, 'success_rate': 88, 'throughput': 52},
            {'original_index': 1, 'service_id': 6, 'response_time': 85, 'cost': 9.5,
             'availability': 94, 'reliability': 89, 'success_rate': 86, 'throughput': 50},
        ]
    }

    # Apply pruning
    pruner = ParetoSkylinePruner(enable_logging=True)
    result = pruner.prune_workflow_candidates(sample_workflow)

    # Display results
    print("\n" + pruner.get_statistics_summary())

    print("\nIndex Mappings:")
    for task_id, mapping in result['index_mappings'].items():
        print(f"{task_id}: {mapping}")
