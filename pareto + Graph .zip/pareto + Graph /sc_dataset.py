import numpy as np
import linecache
import tensorflow as tf
from pareto_pruning import ParetoSkylinePruner
import os


class SC_DataGenerator(object):
    np.random.seed(1)

    def gen_instance(self,dimension, f, load_qos=True):
        num_service = []
        #service1 = []
        workflow_data = {}

        f.readline()
        line = f.readline()
        candidates_c = line.split(' ')
        candidates = []
        for index in range(len(candidates_c)):
            candidates.append(candidates_c[index])

        task_id = 0
        for candidate in candidates:
            num = 0
            service_ids = []  # Pareto Store service IDs for this task
            f1 = open('服务名聚类最终结果/' + candidate + '.txt')
            line1 = f1.readline()
            while line1:
                num = num+1
                if load_qos: # pareto Extract service ID
                    # Extract service ID from line (format: "id:...")
                    atom = line1.split(':')[0]
                    service_ids.append(int(atom))
                line1 = f1.readline()
            f1.close()
            num_service.append(num)

            # Pareto Load QoS values if requested
            if load_qos and service_ids:
                qos_list = self.load_qos_values(service_ids)

                # Structure data for pareto pruning
                candidates_with_qos = []
                for idx, qos in enumerate(qos_list):
                    candidate_data = {
                        'original_index': idx,
                        'service_id': qos['id'],
                        'response_time': qos['response_time'],
                        'cost': qos['cost'],
                        'availability': qos['availability'],
                        'reliability': qos['reliability'],
                        'success_rate': qos['successability'],
                        'throughput': qos['throughput']
                    }
                    candidates_with_qos.append(candidate_data)

                workflow_data[task_id] = candidates_with_qos

            task_id += 1

        return num_service, workflow_data

    def train_batch(self, dimension, position,  i, config=None, calattr=None):

        f = open(position + '/' + i + '/nodeSet.txt', 'r', encoding='utf-8')

        num_original, workflow_data = self.gen_instance(dimension, f, load_qos=True)
        f.close()

        print("APPLYING PARETO SKYLINE PRUNING...")
        pruner = ParetoSkylinePruner(enable_logging=True)
        pruning_result = pruner.prune_workflow_candidates(workflow_data)

        pruned_candidates = pruning_result['pruned_data']
        index_mappings = pruning_result['index_mappings']
        pruning_stats = pruning_result['statistics']

        # Save statistics to file
        stats_dir = 'testlog/pruning'
        if not os.path.exists(stats_dir):
            os.makedirs(stats_dir)
        stats_file = os.path.join(stats_dir, f'pruning_stats_{i.replace("/", "_")}.txt')
        pruner.save_statistics(stats_file)
        print(f"Pruning statistics saved to: {stats_file}")

        num = []
        count = 0
        for task_id in sorted(pruned_candidates.keys()):
            num_skyline = len(pruned_candidates[task_id])
            num.append(num_skyline)
            count += num_skyline

        print(f"Action space reduced from {sum(num_original)} to {count} candidates")

        if config is not None and calattr is not None:
            graph_features = calattr.extract_graph_features()  # Shape: (node_num, 8)
            input_ = self._format_graph_features(graph_features)  # Shape: (1, node_num*8)
            print(f"[Graph-Aware Mode] Input shape: {input_.shape}")

        else:
            raise ValueError("config and calattr are empty")

        return input_, num, count, pruned_candidates, index_mappings, pruning_stats

    def _format_graph_features(self, features):
        # Normalize each feature column separately (per-feature)
        normalized = np.zeros_like(features, dtype=float)
        for col in range(features.shape[1]):  # 8 columns
            col_min = np.min(features[:, col])
            col_max = np.max(features[:, col])
            if col_max - col_min > 0:
                normalized[:, col] = (features[:, col] - col_min) / (col_max - col_min)
            else:
                normalized[:, col] = features[:, col]

        # Flatten from (node_num, 8) to (node_num * 8)
        flat_features = normalized.flatten()

        # Reshape to (1, node_num * 8) for batch processing
        input_ = flat_features.reshape(1, -1)

        return input_

    def _normalize_features(self, features):

        min_val = np.min(features)
        max_val = np.max(features)

        if max_val - min_val > 0:
            normalized = (features - min_val) / (max_val - min_val)
        else:
            normalized = features

        return normalized

    def calculate_cost(self, response_time, availability, throughput, successability, reliability,
                       max_time, max_avail, max_throu, max_success, max_reli):

        cost = (0.2 * (response_time / max_time) +
                0.2 * (availability / max_avail) +
                0.2 * (throughput / max_throu) +
                0.2 * (successability / max_success) +
                0.2 * (reliability / max_reli))
        return cost

    def load_qos_values(self, service_ids):

        qos_data = []

        #  Find max values for cost calculation
        temp_data = []
        for service_id in service_ids:
            try:
                line = linecache.getline('QWS_Dataset.txt', service_id)
                if line:
                    values = line.strip().split(',')
                    temp_data.append({
                        'id': int(values[0]),
                        'response_time': float(values[1]),
                        'availability': float(values[2]),
                        'throughput': float(values[3]),
                        'successability': float(values[4]),
                        'reliability': float(values[5])
                    })
            except Exception as e:
                print(f"Error loading service {service_id}: {e}")
                continue

        # Calculate max values for cost normalization
        if temp_data:
            max_time = max([d['response_time'] for d in temp_data])
            max_avail = max([d['availability'] for d in temp_data])
            max_throu = max([d['throughput'] for d in temp_data])
            max_success = max([d['successability'] for d in temp_data])
            max_reli = max([d['reliability'] for d in temp_data])

            #  Calculate cost for each service
            for data in temp_data:
                cost = self.calculate_cost(
                    data['response_time'], data['availability'], data['throughput'],
                    data['successability'], data['reliability'],
                    max_time, max_avail, max_throu, max_success, max_reli
                )
                data['cost'] = cost
                qos_data.append(data)

        return qos_data
